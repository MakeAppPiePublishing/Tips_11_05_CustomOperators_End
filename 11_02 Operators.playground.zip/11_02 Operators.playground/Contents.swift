//
//  MenuModel.swift
//  Pizza
//
//  Created by Steven Lipton on 9/1/19.
//  Copyright © 2019 Steven Lipton. All rights reserved.
// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 11 (Q3 2020) video 02
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Learn to code your own operators.
//  For more code, go to http://bit.ly/AppPieGithub


import Foundation
var  a = 1
a = a + 1
a += 1
var string1 = "Hello,"
string1 = string1 + " pizza"

///A basic description of a menu item
///`name` the name of the food item
///`description` the decription of the food item
///`price` the base price for the menu item
///`rating` the rating for the menu item
struct MenuItem:Identifiable{
    var id:Int
    var name:String
    var description:String
    var price:Double
    var rating:Int
    static func + (item1:MenuItem,item2:MenuItem)->[MenuItem]{
        var itemList = [item1] + [item2]
        for index in 0..<itemList.count{
            itemList[index].id = index
        }
        return itemList
    }
    static func + (list:[MenuItem],item2:MenuItem)->[MenuItem]{
        var itemList = list + [item2]
        for index in 0..<itemList.count{
            itemList[index].id = index
        }
        return itemList
    }

}

struct MenuModel{
    var menu:[MenuItem] = [
        MenuItem(id: 0,name: "Margherita", description: "The classic pizza of Buffalo. Mozzarella, tomatoes, and basil on a classic crust.", price: 12.00, rating: 5 ),
        MenuItem(id: 1,name: "Huli Chicken", description: "Our original Hawaiian street food pizza, with huli huli chicken, onions, ginger, crushed macadamia nuts, tomato sauce and cheese on a classic crust.", price: 14.00, rating: 6),
        MenuItem(id: 2,name: "Quattro Formaggi", description: "A blend of Asiago, Parmesan, buffalo mozzarella, and Gorgonzola on a thin crust.", price: 13.00, rating: 5),
        MenuItem(id: 3,name: "Longboard", description: "A very long flatbread for vegetarians and vegans, made with olive oil, mushrooms, garlic, fresh ginger, and macadamias, sweetened with lilikoi.", price: 15.00, rating: 4),
        MenuItem(id: 4,name: "The Big Island", description: "A meaty calzone exploding like a volcano. Beef and pork combined with vegetables, pineapple, and a special \"lava sauce\" leaking out the top crater. Definitely share this one.", price: 17.00, rating: 6),
        MenuItem(id: 5,name: "Pepperoni", description: "The New York Classic version. A thin crust with pizza sauce, cheese, and pepperoni.", price: 10.00, rating: 5),
        MenuItem(id: 6,name: "Chicago Deep Dish", description: "The classic deep dish cheese pizza. 2\"Thick and filled with sauce and cheese. ", price: 17.00, rating: 6),
        MenuItem(id: 7,name: "Meat Lovers", description: "A deep dish for the carnivore. Sausage and pepperoni in the classic Chicago deep dish.", price: 20.00, rating: 4),
        MenuItem(id: 8,name: "BBQ Chicken", description: "Grilled chicken with barbecue sauce, red onions, and peppers.", price: 14.00, rating: 5),
        MenuItem(id: 9, name: "Hawaiian", description: "It may be from the mainland, but we make it our own. Pineapple, SPAM, cheese, onions, and tomato sauce on a thin crust.", price: 14.00, rating: 5)
    ]
}

extension MenuModel{
    static func + (model:MenuModel, item: MenuItem) -> MenuModel{
        var newModel = model
        newModel.menu = newModel.menu + item
        return newModel
    }
    static func += (model:inout MenuModel, item:MenuItem){
        model = model + item
    }
}


let testMenuItem =  MenuItem(id: 1, name: "Mister Detroit", description: "Pepperoni infused rectangular pan crust with Wisconsin Brick cheese, tomato sauce, onions and peppers.", price: 14.00, rating: 3)

testMenuItem + testMenuItem
var model = MenuModel()
model.menu + testMenuItem

(model + testMenuItem).menu
model += testMenuItem
model.menu
